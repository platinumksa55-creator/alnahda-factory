import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowLeft, Users, Award, Globe, Clock } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

const stats = [
  {
    icon: Clock,
    number: "25+",
    label: "سنة من الخبرة",
  },
  {
    icon: Users,
    number: "500+",
    label: "عميل راضٍ",
  },
  {
    icon: Award,
    number: "50+",
    label: "جائزة ومعترف",
  },
  {
    icon: Globe,
    number: "15+",
    label: "دولة نصدر إليها",
  },
]

const values = [
  {
    title: "الجودة",
    description: "نلتزم بأعلى معايير الجودة في كل خطوة من خطوات الإنتاج",
    icon: Award,
  },
  {
    title: "الابتكار",
    description: "نستثمر في أحدث التقنيات لتطوير منتجات مبتكرة",
    icon: Globe,
  },
  {
    title: "الموثوقية",
    description: "شريك موثوق يلتزم بالمواعيد ويحافظ على الوعود",
    icon: Users,
  },
  {
    title: "الاستدامة",
    description: "نحرص على الممارسات المستدامة والصديقة للبيئة",
    icon: Clock,
  },
]

export default function AboutPage() {
  return (
    <main>
      <Navigation />

      {/* Hero Section */}
      <section className="relative pt-20 pb-16 lg:pb-24 bg-gradient-to-b from-neutral-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="font-work-sans font-bold text-4xl lg:text-5xl text-neutral-900 mb-6 text-balance">من نحن</h1>
            <p className="font-open-sans text-xl text-neutral-600 max-w-3xl mx-auto text-balance">
              رحلة من الشغف والإبداع في عالم النسيج، نسج تراث من الجودة والتميز عبر العقود
            </p>
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-16 lg:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
            <div>
              <h2 className="font-work-sans font-bold text-3xl lg:text-4xl text-neutral-900 mb-6 text-balance">
                قصتنا
              </h2>
              <p className="font-open-sans text-lg text-neutral-700 mb-6 leading-relaxed">
                بدأت رحلتنا في عام 1999 برؤية واضحة: إنتاج أجود أنواع الأقمشة والمنسوجات التي تجمع بين الحرفية التقليدية
                والتقنيات الحديثة. منذ ذلك الحين، نمونا لنصبح واحدًا من أبرز المصانع في المنطقة.
              </p>
              <p className="font-open-sans text-lg text-neutral-700 mb-6 leading-relaxed">
                نفخر بفريقنا المتخصص من الحرفيين والمهندسين الذين يعملون بشغف لضمان أن كل منتج يحمل بصمة الجودة والتميز
                التي نشتهر بها.
              </p>
              <p className="font-open-sans text-lg text-neutral-700 mb-8 leading-relaxed">
                اليوم، نخدم عملاء في أكثر من 15 دولة حول العالم، ونواصل الاستثمار في التطوير والابتكار لنبقى في المقدمة.
              </p>
            </div>
            <div>
              <Image
                src="/textile-factory-workers-operating-modern-weaving-m.png"
                alt="مصنع النسيج - تاريخنا وتطورنا"
                width={600}
                height={500}
                className="rounded-lg shadow-lg w-full h-auto"
              />
            </div>
          </div>

          {/* Stats */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
            {stats.map((stat, index) => (
              <Card key={index} className="text-center p-6 border-0 shadow-lg">
                <CardContent className="p-0">
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <stat.icon className="w-8 h-8 text-primary" />
                  </div>
                  <div className="font-work-sans font-bold text-3xl text-neutral-900 mb-2">{stat.number}</div>
                  <div className="font-open-sans text-neutral-600">{stat.label}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-16 lg:py-24 bg-neutral-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12">
            <Card className="p-8 border-0 shadow-lg">
              <CardContent className="p-0">
                <h3 className="font-work-sans font-bold text-2xl text-neutral-900 mb-4">رسالتنا</h3>
                <p className="font-open-sans text-lg text-neutral-700 leading-relaxed">
                  نسعى لتقديم أجود أنواع الأقمشة والمنسوجات التي تلبي احتياجات عملائنا وتتجاوز توقعاتهم، من خلال الجمع
                  بين الخبرة التقليدية والتقنيات المتطورة، مع الحفاظ على أعلى معايير الجودة والاستدامة.
                </p>
              </CardContent>
            </Card>

            <Card className="p-8 border-0 shadow-lg">
              <CardContent className="p-0">
                <h3 className="font-work-sans font-bold text-2xl text-neutral-900 mb-4">رؤيتنا</h3>
                <p className="font-open-sans text-lg text-neutral-700 leading-relaxed">
                  أن نكون الخيار الأول عالميًا في صناعة النسيج، معروفين بالجودة الاستثنائية والابتكار المستمر، ونساهم في
                  تطوير الصناعة من خلال الممارسات المستدامة والتقنيات المتقدمة.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-16 lg:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="font-work-sans font-bold text-3xl lg:text-4xl text-neutral-900 mb-4 text-balance">قيمنا</h2>
            <p className="font-open-sans text-lg text-neutral-600 max-w-2xl mx-auto text-balance">
              القيم التي توجه عملنا وتشكل هويتنا كشركة رائدة في صناعة النسيج
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <Card
                key={index}
                className="text-center p-6 border-0 shadow-lg hover:shadow-xl transition-shadow duration-300"
              >
                <CardContent className="p-0">
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <value.icon className="w-8 h-8 text-primary" />
                  </div>
                  <h3 className="font-work-sans font-semibold text-xl text-neutral-900 mb-3">{value.title}</h3>
                  <p className="font-open-sans text-neutral-600 leading-relaxed">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Facilities Gallery */}
      <section className="py-16 lg:py-24 bg-neutral-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="font-work-sans font-bold text-3xl lg:text-4xl text-neutral-900 mb-4 text-balance">
              مرافقنا
            </h2>
            <p className="font-open-sans text-lg text-neutral-600 max-w-2xl mx-auto text-balance">
              جولة في مصنعنا المتطور المجهز بأحدث التقنيات والآلات
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="relative overflow-hidden rounded-lg shadow-lg group">
              <Image
                src="/textile-factory-workers-operating-modern-weaving-m.png"
                alt="قسم النسيج الرئيسي"
                width={400}
                height={300}
                className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-black/40 flex items-end">
                <div className="p-6 text-white">
                  <h3 className="font-work-sans font-semibold text-lg mb-2">قسم النسيج الرئيسي</h3>
                  <p className="font-open-sans text-sm opacity-90">أحدث آلات النسيج المتطورة</p>
                </div>
              </div>
            </div>

            <div className="relative overflow-hidden rounded-lg shadow-lg group">
              <Image
                src="/luxury-cotton-fabric-texture-close-up.png"
                alt="مختبر مراقبة الجودة"
                width={400}
                height={300}
                className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-black/40 flex items-end">
                <div className="p-6 text-white">
                  <h3 className="font-work-sans font-semibold text-lg mb-2">مختبر مراقبة الجودة</h3>
                  <p className="font-open-sans text-sm opacity-90">فحص دقيق لكل منتج</p>
                </div>
              </div>
            </div>

            <div className="relative overflow-hidden rounded-lg shadow-lg group">
              <Image
                src="/modern-blended-textile-fabric-samples.png"
                alt="قسم التطوير والابتكار"
                width={400}
                height={300}
                className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-black/40 flex items-end">
                <div className="p-6 text-white">
                  <h3 className="font-work-sans font-semibold text-lg mb-2">قسم التطوير والابتكار</h3>
                  <p className="font-open-sans text-sm opacity-90">تطوير منتجات جديدة</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 lg:py-24 bg-primary text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-work-sans font-bold text-3xl lg:text-4xl mb-6 text-balance">هل تريد معرفة المزيد؟</h2>
          <p className="font-open-sans text-lg lg:text-xl mb-8 opacity-90 text-balance max-w-2xl mx-auto">
            تواصل معنا لمعرفة كيف يمكننا مساعدتك في تحقيق أهدافك
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button asChild size="lg" variant="secondary" className="bg-white text-primary hover:bg-neutral-100 px-8">
              <Link href="/products" className="flex items-center gap-2">
                استكشف منتجاتنا
                <ArrowLeft className="w-5 h-5 rotate-180" />
              </Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-primary px-8 bg-transparent"
            >
              <Link href="/contact">تواصل معنا</Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
