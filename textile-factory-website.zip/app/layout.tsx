import type React from "react"
import type { Metadata } from "next"
import { GeistSans } from "geist/font/sans"
import { GeistMono } from "geist/font/mono"
import { Work_Sans, Open_Sans } from "next/font/google"
import { LanguageProvider } from "@/components/language-provider"
import "./globals.css"

const workSans = Work_Sans({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-work-sans",
  weight: ["400", "600", "700"],
})

const openSans = Open_Sans({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-open-sans",
  weight: ["400", "500", "600"],
})

export const metadata: Metadata = {
  title: "مصنع النسيج المتميز | Premium Textile Factory",
  description:
    "مصنع نسيج متخصص في إنتاج أجود أنواع الأقمشة والمنسوجات | Specialized textile factory producing high-quality fabrics and textiles",
  generator: "v0.app",
  keywords: "textile, fabric, manufacturing, نسيج, أقمشة, مصنع",
  authors: [{ name: "Textile Factory" }],
  openGraph: {
    title: "مصنع النسيج المتميز | Premium Textile Factory",
    description: "الجودة تُنسج في كل خيط | Quality Woven into Every Thread",
    type: "website",
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="ar">
      <body
        className={`font-sans ${GeistSans.variable} ${GeistMono.variable} ${workSans.variable} ${openSans.variable} antialiased`}
      >
        <LanguageProvider>{children}</LanguageProvider>
      </body>
    </html>
  )
}
