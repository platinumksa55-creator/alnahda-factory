"use client"

import type React from "react"

import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Phone, Mail, MapPin, Clock, MessageCircle, Send, CheckCircle } from "lucide-react"
import Link from "next/link"
import { useState } from "react"

const contactInfo = [
  {
    icon: Phone,
    title: "الهاتف",
    details: ["+966 12 345 6789", "+966 12 345 6790"],
    action: "tel:+966123456789",
  },
  {
    icon: Mail,
    title: "البريد الإلكتروني",
    details: ["info@alnahda-textiles.com", "sales@alnahda-textiles.com"],
    action: "mailto:info@alnahda-textiles.com",
  },
  {
    icon: MessageCircle,
    title: "واتساب",
    details: ["+966 50 123 4567"],
    action: "https://wa.me/966501234567",
  },
  {
    icon: MapPin,
    title: "العنوان",
    details: ["المملكة العربية السعودية", "الرياض، حي الصناعية، شارع الملك فهد"],
    action: "https://maps.google.com",
  },
]

const workingHours = [
  { day: "الأحد - الخميس", hours: "8:00 ص - 6:00 م" },
  { day: "الجمعة", hours: "مغلق" },
  { day: "السبت", hours: "9:00 ص - 2:00 م" },
]

const serviceOptions = [
  "أقمشة القطن",
  "منسوجات الكتان",
  "أقمشة الحرير",
  "منسوجات مخلوطة",
  "أقمشة الديكور المنزلي",
  "منسوجات صناعية",
  "طلب مخصص",
  "استشارة تقنية",
]

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    company: "",
    phone: "",
    service: "",
    message: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (value: string) => {
    setFormData((prev) => ({ ...prev, service: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate form submission
    await new Promise((resolve) => setTimeout(resolve, 2000))

    console.log("[v0] Form submitted:", formData)
    setIsSubmitted(true)
    setIsSubmitting(false)

    // Reset form after 3 seconds
    setTimeout(() => {
      setIsSubmitted(false)
      setFormData({
        name: "",
        email: "",
        company: "",
        phone: "",
        service: "",
        message: "",
      })
    }, 3000)
  }

  return (
    <main>
      <Navigation />

      {/* Hero Section */}
      <section className="relative pt-20 pb-16 lg:pb-24 bg-gradient-to-b from-neutral-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="font-work-sans font-bold text-4xl lg:text-5xl text-neutral-900 mb-6 text-balance">
              تواصل معنا
            </h1>
            <p className="font-open-sans text-xl text-neutral-600 max-w-3xl mx-auto text-balance">
              نحن هنا لمساعدتك. تواصل معنا للحصول على استشارة مجانية أو عرض أسعار مخصص
            </p>
          </div>
        </div>
      </section>

      {/* Contact Form and Info */}
      <section className="py-16 lg:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Information */}
            <div>
              <h2 className="font-work-sans font-bold text-2xl lg:text-3xl text-neutral-900 mb-8">معلومات التواصل</h2>

              <div className="space-y-6 mb-8">
                {contactInfo.map((info, index) => (
                  <Card key={index} className="border-0 shadow-md hover:shadow-lg transition-shadow duration-300">
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-4 rtl:space-x-reverse">
                        <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                          <info.icon className="w-6 h-6 text-primary" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-work-sans font-semibold text-lg text-neutral-900 mb-2">{info.title}</h3>
                          <div className="space-y-1">
                            {info.details.map((detail, idx) => (
                              <p key={idx} className="font-open-sans text-neutral-700">
                                {info.action ? (
                                  <Link
                                    href={info.action}
                                    className="hover:text-primary transition-colors"
                                    target={info.action.startsWith("http") ? "_blank" : undefined}
                                  >
                                    {detail}
                                  </Link>
                                ) : (
                                  detail
                                )}
                              </p>
                            ))}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Working Hours */}
              <Card className="border-0 shadow-md">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-4 rtl:space-x-reverse">
                    <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <Clock className="w-6 h-6 text-primary" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-work-sans font-semibold text-lg text-neutral-900 mb-3">ساعات العمل</h3>
                      <div className="space-y-2">
                        {workingHours.map((schedule, index) => (
                          <div key={index} className="flex justify-between items-center">
                            <span className="font-open-sans text-neutral-700">{schedule.day}</span>
                            <span className="font-open-sans font-medium text-neutral-900">{schedule.hours}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Contact Form */}
            <div>
              <Card className="border-0 shadow-lg">
                <CardContent className="p-8">
                  <h2 className="font-work-sans font-bold text-2xl text-neutral-900 mb-6">أرسل لنا رسالة</h2>

                  {isSubmitted ? (
                    <div className="text-center py-8">
                      <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <CheckCircle className="w-8 h-8 text-green-600" />
                      </div>
                      <h3 className="font-work-sans font-semibold text-xl text-neutral-900 mb-2">تم إرسال الرسالة!</h3>
                      <p className="font-open-sans text-neutral-600">
                        شكراً لتواصلك معنا. سنقوم بالرد عليك في أقرب وقت ممكن.
                      </p>
                    </div>
                  ) : (
                    <form onSubmit={handleSubmit} className="space-y-6">
                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="name" className="font-open-sans font-medium text-neutral-700">
                            الاسم الكامل *
                          </Label>
                          <Input
                            id="name"
                            name="name"
                            type="text"
                            required
                            value={formData.name}
                            onChange={handleInputChange}
                            className="mt-1"
                            placeholder="أدخل اسمك الكامل"
                          />
                        </div>
                        <div>
                          <Label htmlFor="email" className="font-open-sans font-medium text-neutral-700">
                            البريد الإلكتروني *
                          </Label>
                          <Input
                            id="email"
                            name="email"
                            type="email"
                            required
                            value={formData.email}
                            onChange={handleInputChange}
                            className="mt-1"
                            placeholder="example@email.com"
                          />
                        </div>
                      </div>

                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="company" className="font-open-sans font-medium text-neutral-700">
                            اسم الشركة
                          </Label>
                          <Input
                            id="company"
                            name="company"
                            type="text"
                            value={formData.company}
                            onChange={handleInputChange}
                            className="mt-1"
                            placeholder="اسم شركتك (اختياري)"
                          />
                        </div>
                        <div>
                          <Label htmlFor="phone" className="font-open-sans font-medium text-neutral-700">
                            رقم الهاتف *
                          </Label>
                          <Input
                            id="phone"
                            name="phone"
                            type="tel"
                            required
                            value={formData.phone}
                            onChange={handleInputChange}
                            className="mt-1"
                            placeholder="+966 50 123 4567"
                          />
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="service" className="font-open-sans font-medium text-neutral-700">
                          الخدمة المطلوبة *
                        </Label>
                        <Select onValueChange={handleSelectChange} required>
                          <SelectTrigger className="mt-1">
                            <SelectValue placeholder="اختر الخدمة المطلوبة" />
                          </SelectTrigger>
                          <SelectContent>
                            {serviceOptions.map((service, index) => (
                              <SelectItem key={index} value={service}>
                                {service}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label htmlFor="message" className="font-open-sans font-medium text-neutral-700">
                          الرسالة *
                        </Label>
                        <Textarea
                          id="message"
                          name="message"
                          required
                          value={formData.message}
                          onChange={handleInputChange}
                          className="mt-1 min-h-32"
                          placeholder="اكتب رسالتك هنا... أخبرنا عن احتياجاتك ومتطلباتك"
                        />
                      </div>

                      <Button
                        type="submit"
                        size="lg"
                        disabled={isSubmitting}
                        className="w-full bg-primary hover:bg-primary/90 text-white"
                      >
                        {isSubmitting ? (
                          <div className="flex items-center gap-2">
                            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                            جاري الإرسال...
                          </div>
                        ) : (
                          <div className="flex items-center gap-2">
                            <Send className="w-4 h-4" />
                            إرسال الرسالة
                          </div>
                        )}
                      </Button>
                    </form>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Map Section */}
      <section className="py-16 bg-neutral-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <h2 className="font-work-sans font-bold text-2xl lg:text-3xl text-neutral-900 mb-4">موقعنا</h2>
            <p className="font-open-sans text-lg text-neutral-600">زورنا في مصنعنا الواقع في قلب المنطقة الصناعية</p>
          </div>

          <Card className="border-0 shadow-lg overflow-hidden">
            <CardContent className="p-0">
              <div className="w-full h-96 bg-neutral-200 flex items-center justify-center">
                <div className="text-center">
                  <MapPin className="w-12 h-12 text-neutral-400 mx-auto mb-4" />
                  <p className="font-open-sans text-neutral-600">خريطة تفاعلية</p>
                  <p className="font-open-sans text-sm text-neutral-500">
                    المملكة العربية السعودية، الرياض
                    <br />
                    حي الصناعية، شارع الملك فهد
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Quick Contact CTA */}
      <section className="py-16 lg:py-24 bg-primary text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-work-sans font-bold text-3xl lg:text-4xl mb-6 text-balance">تحتاج مساعدة فورية؟</h2>
          <p className="font-open-sans text-lg lg:text-xl mb-8 opacity-90 text-balance max-w-2xl mx-auto">
            فريقنا متاح للرد على استفساراتك وتقديم المساعدة الفورية
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button asChild size="lg" variant="secondary" className="bg-white text-primary hover:bg-neutral-100 px-8">
              <Link href="tel:+966123456789" className="flex items-center gap-2">
                <Phone className="w-5 h-5" />
                اتصل الآن
              </Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-primary px-8 bg-transparent"
            >
              <Link href="https://wa.me/966501234567" target="_blank" className="flex items-center gap-2">
                <MessageCircle className="w-5 h-5" />
                واتساب
              </Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
