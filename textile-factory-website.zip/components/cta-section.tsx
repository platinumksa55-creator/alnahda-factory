"use client"

import { Button } from "@/components/ui/button"
import { Phone, Mail } from "lucide-react"
import Link from "next/link"
import { useLanguage } from "@/components/language-provider"

export function CTASection() {
  const { t } = useLanguage()

  return (
    <section className="py-16 lg:py-24 bg-primary text-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="font-work-sans font-bold text-3xl lg:text-4xl mb-6 text-balance">{t("ctaTitle")}</h2>
        <p className="font-open-sans text-lg lg:text-xl mb-8 opacity-90 text-balance max-w-2xl mx-auto">
          {t("ctaSubtitle")}
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <Button asChild size="lg" variant="secondary" className="bg-white text-primary hover:bg-neutral-100 px-8">
            <Link href="/contact" className="flex items-center gap-2">
              <Mail className="w-5 h-5" />
              {t("getQuote")}
            </Link>
          </Button>
          <Button
            asChild
            size="lg"
            variant="outline"
            className="border-white text-white hover:bg-white hover:text-primary px-8 bg-transparent"
          >
            <Link href="tel:+966123456789" className="flex items-center gap-2">
              <Phone className="w-5 h-5" />
              {t("callNow")}
            </Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
