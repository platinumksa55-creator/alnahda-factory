"use client"

import Link from "next/link"
import Image from "next/image"
import { Phone, Mail, MapPin, Facebook, Twitter, Instagram, Linkedin } from "lucide-react"
import { useLanguage } from "@/components/language-provider"

export function Footer() {
  const { t } = useLanguage()

  return (
    <footer className="bg-neutral-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="lg:col-span-2">
            <div className="flex items-center space-x-3 rtl:space-x-reverse mb-4">
              <Image
                src="/images/al-nahda-logo.png"
                alt="Al-Nahda for Textiles"
                width={40}
                height={40}
                className="w-10 h-10"
              />
              <span className="font-work-sans font-bold text-xl">{t("companyName")}</span>
            </div>
            <p className="font-open-sans text-neutral-300 mb-6 leading-relaxed max-w-md">{t("footerDescription")}</p>
            <div className="flex space-x-4 rtl:space-x-reverse">
              <Link href="#" className="text-neutral-400 hover:text-white transition-colors">
                <Facebook className="w-5 h-5" />
              </Link>
              <Link href="#" className="text-neutral-400 hover:text-white transition-colors">
                <Twitter className="w-5 h-5" />
              </Link>
              <Link href="#" className="text-neutral-400 hover:text-white transition-colors">
                <Instagram className="w-5 h-5" />
              </Link>
              <Link href="#" className="text-neutral-400 hover:text-white transition-colors">
                <Linkedin className="w-5 h-5" />
              </Link>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-work-sans font-semibold text-lg mb-4">{t("quickLinks")}</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="font-open-sans text-neutral-300 hover:text-white transition-colors">
                  {t("home")}
                </Link>
              </li>
              <li>
                <Link href="/about" className="font-open-sans text-neutral-300 hover:text-white transition-colors">
                  {t("about")}
                </Link>
              </li>
              <li>
                <Link href="/products" className="font-open-sans text-neutral-300 hover:text-white transition-colors">
                  {t("products")}
                </Link>
              </li>
              <li>
                <Link href="/contact" className="font-open-sans text-neutral-300 hover:text-white transition-colors">
                  {t("contact")}
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="font-work-sans font-semibold text-lg mb-4">{t("contactInfo")}</h3>
            <ul className="space-y-3">
              <li className="flex items-center space-x-3 rtl:space-x-reverse">
                <Phone className="w-4 h-4 text-primary flex-shrink-0" />
                <span className="font-open-sans text-neutral-300">+966 12 345 6789</span>
              </li>
              <li className="flex items-center space-x-3 rtl:space-x-reverse">
                <Mail className="w-4 h-4 text-primary flex-shrink-0" />
                <span className="font-open-sans text-neutral-300">info@alnahda-textiles.com</span>
              </li>
              <li className="flex items-start space-x-3 rtl:space-x-reverse">
                <MapPin className="w-4 h-4 text-primary flex-shrink-0 mt-1" />
                <span className="font-open-sans text-neutral-300">
                  المملكة العربية السعودية
                  <br />
                  الرياض، حي الصناعية
                </span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-neutral-800 mt-8 pt-8 text-center">
          <p className="font-open-sans text-neutral-400">
            © 2024 {t("companyName")}. {t("allRightsReserved")}.
          </p>
        </div>
      </div>
    </footer>
  )
}
