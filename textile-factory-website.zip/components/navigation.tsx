"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Menu, X, Globe } from "lucide-react"
import { useLanguage } from "@/components/language-provider"

export function Navigation() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const { locale, setLocale, t } = useLanguage()

  const toggleLanguage = () => {
    setLocale(locale === "ar" ? "en" : "ar")
  }

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-sm border-b border-neutral-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-2 rtl:space-x-reverse">
            <Image
              src="/images/al-nahda-logo.png"
              alt="Al-Nahda for Textiles"
              width={40}
              height={40}
              className="w-10 h-10"
            />
            <span className="font-work-sans font-bold text-xl text-primary">{t("companyName")}</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8 rtl:space-x-reverse">
            <Link href="/" className="text-neutral-700 hover:text-primary transition-colors font-medium">
              {t("home")}
            </Link>
            <Link href="/about" className="text-neutral-700 hover:text-primary transition-colors font-medium">
              {t("about")}
            </Link>
            <Link href="/products" className="text-neutral-700 hover:text-primary transition-colors font-medium">
              {t("products")}
            </Link>
            <Link href="/contact" className="text-neutral-700 hover:text-primary transition-colors font-medium">
              {t("contact")}
            </Link>

            <Button
              variant="outline"
              size="sm"
              className="flex items-center gap-2 bg-transparent"
              onClick={toggleLanguage}
            >
              <Globe className="w-4 h-4" />
              {t("switchToEnglish")}
            </Button>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <Button variant="ghost" size="sm" onClick={() => setIsMenuOpen(!isMenuOpen)}>
              {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 bg-white border-t border-neutral-200">
              <Link
                href="/"
                className="block px-3 py-2 text-neutral-700 hover:text-primary transition-colors font-medium"
                onClick={() => setIsMenuOpen(false)}
              >
                {t("home")}
              </Link>
              <Link
                href="/about"
                className="block px-3 py-2 text-neutral-700 hover:text-primary transition-colors font-medium"
                onClick={() => setIsMenuOpen(false)}
              >
                {t("about")}
              </Link>
              <Link
                href="/products"
                className="block px-3 py-2 text-neutral-700 hover:text-primary transition-colors font-medium"
                onClick={() => setIsMenuOpen(false)}
              >
                {t("products")}
              </Link>
              <Link
                href="/contact"
                className="block px-3 py-2 text-neutral-700 hover:text-primary transition-colors font-medium"
                onClick={() => setIsMenuOpen(false)}
              >
                {t("contact")}
              </Link>
              <div className="px-3 py-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="flex items-center gap-2 bg-transparent"
                  onClick={toggleLanguage}
                >
                  <Globe className="w-4 h-4" />
                  {t("switchToEnglish")}
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  )
}
