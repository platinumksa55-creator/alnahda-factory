"use client"

import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { useLanguage } from "@/components/language-provider"

export function AboutSnippet() {
  const { t } = useLanguage()

  return (
    <section className="py-16 lg:py-24 bg-neutral-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="order-2 lg:order-1">
            <h2 className="font-work-sans font-bold text-3xl lg:text-4xl text-neutral-900 mb-6 text-balance">
              {t("aboutTitle")}
            </h2>
            <p className="font-open-sans text-lg text-neutral-700 mb-6 leading-relaxed">{t("aboutDescription1")}</p>
            <p className="font-open-sans text-lg text-neutral-700 mb-8 leading-relaxed">{t("aboutDescription2")}</p>
            <Button
              asChild
              variant="outline"
              size="lg"
              className="border-primary text-primary hover:bg-primary hover:text-white bg-transparent"
            >
              <Link href="/about" className="flex items-center gap-2">
                {t("learnMore")}
                <ArrowLeft className="w-5 h-5 rotate-180" />
              </Link>
            </Button>
          </div>
          <div className="order-1 lg:order-2">
            <Image
              src="/textile-factory-workers-operating-modern-weaving-m.png"
              alt="مصنع النسيج - العمال والآلات"
              width={600}
              height={500}
              className="rounded-lg shadow-lg w-full h-auto"
            />
          </div>
        </div>
      </div>
    </section>
  )
}
