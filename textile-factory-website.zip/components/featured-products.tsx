"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { useLanguage } from "@/components/language-provider"

const featuredProducts = [
  {
    id: 1,
    name: "أقمشة القطن الفاخرة",
    description: "أقمشة قطنية عالية الجودة مناسبة لجميع الاستخدامات",
    image: "/luxury-cotton-fabric-texture-close-up.png",
    slug: "luxury-cotton-fabrics",
  },
  {
    id: 2,
    name: "منسوجات الكتان الطبيعي",
    description: "كتان طبيعي 100% بألوان متنوعة وجودة استثنائية",
    image: "/natural-linen-fabric-texture-in-earth-tones.png",
    slug: "natural-linen-textiles",
  },
  {
    id: 3,
    name: "أقمشة الحرير المميزة",
    description: "حرير فاخر بلمعان طبيعي وملمس ناعم",
    image: "/premium-silk-fabric-with-natural-sheen.png",
    slug: "premium-silk-fabrics",
  },
  {
    id: 4,
    name: "منسوجات مخلوطة متطورة",
    description: "أقمشة مبتكرة تجمع بين الراحة والمتانة",
    image: "/modern-blended-textile-fabric-samples.png",
    slug: "advanced-blended-textiles",
  },
  {
    id: 5,
    name: "أقمشة الديكور المنزلي",
    description: "مجموعة متنوعة من أقمشة التنجيد والستائر",
    image: "/home-decor-upholstery-fabric-patterns.png",
    slug: "home-decor-fabrics",
  },
  {
    id: 6,
    name: "منسوجات صناعية متخصصة",
    description: "أقمشة تقنية للاستخدامات الصناعية المتقدمة",
    image: "/technical-industrial-textile-materials.png",
    slug: "industrial-textiles",
  },
]

export function FeaturedProducts() {
  const { t } = useLanguage()

  return (
    <section className="py-16 lg:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="font-work-sans font-bold text-3xl lg:text-4xl text-neutral-900 mb-4 text-balance">
            {t("featuredTitle")}
          </h2>
          <p className="font-open-sans text-lg text-neutral-600 max-w-2xl mx-auto text-balance">
            {t("featuredSubtitle")}
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {featuredProducts.map((product) => (
            <Card key={product.id} className="group hover:shadow-lg transition-shadow duration-300">
              <CardContent className="p-0">
                <div className="relative overflow-hidden rounded-t-lg">
                  <Image
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    width={400}
                    height={300}
                    className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="p-6">
                  <h3 className="font-work-sans font-semibold text-xl text-neutral-900 mb-2">{product.name}</h3>
                  <p className="font-open-sans text-neutral-600 mb-4 leading-relaxed">{product.description}</p>
                  <Button
                    asChild
                    variant="outline"
                    className="w-full border-primary text-primary hover:bg-primary hover:text-white bg-transparent"
                  >
                    <Link href={`/products/${product.slug}`} className="flex items-center justify-center gap-2">
                      {t("viewDetails")}
                      <ArrowLeft className="w-4 h-4 rotate-180" />
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center">
          <Button asChild size="lg" className="bg-primary hover:bg-primary/90 text-white px-8">
            <Link href="/products" className="flex items-center gap-2">
              {t("viewAllProducts")}
              <ArrowLeft className="w-5 h-5 rotate-180" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
