export type Locale = "ar" | "en"

export const defaultLocale: Locale = "ar"
export const locales: Locale[] = ["ar", "en"]

export const translations = {
  ar: {
    // Navigation
    home: "الرئيسية",
    about: "من نحن",
    products: "منتجاتنا",
    contact: "اتصل بنا",
    switchToEnglish: "English",

    // Homepage
    heroTitle: "الجودة تُنسج في كل خيط",
    heroSubtitle: "نحن نصنع أجود أنواع الأقمشة والمنسوجات بأحدث التقنيات وأعلى معايير الجودة",
    exploreProducts: "اكتشف منتجاتنا",
    contactUs: "تواصل معنا",

    // About snippet
    aboutTitle: "تراث من الإبداع والجودة",
    aboutDescription1:
      "منذ تأسيسنا، نحن ملتزمون بتقديم أجود أنواع الأقمشة والمنسوجات التي تجمع بين الحرفية التقليدية والتقنيات الحديثة. نفخر بكوننا شريكًا موثوقًا للعديد من العلامات التجارية الرائدة.",
    aboutDescription2: "فريقنا المتخصص يعمل بشغف لضمان أن كل منتج يحمل بصمة الجودة والتميز التي نشتهر بها.",
    learnMore: "اعرف المزيد عنا",

    // Featured products
    featuredTitle: "منتجاتنا المميزة",
    featuredSubtitle: "اكتشف مجموعتنا الواسعة من الأقمشة والمنسوجات عالية الجودة",
    viewDetails: "عرض التفاصيل",
    viewAllProducts: "عرض جميع المنتجات",

    // CTA
    ctaTitle: "هل أنت مستعد لبدء مشروعك؟",
    ctaSubtitle: "تواصل معنا اليوم للحصول على استشارة مجانية وعرض أسعار مخصص لاحتياجاتك",
    getQuote: "احصل على عرض أسعار",
    callNow: "اتصل بنا الآن",

    // Footer
    companyName: "النهضة للمنسوجات",
    footerDescription:
      "نحن نصنع أجود أنواع الأقمشة والمنسوجات بأحدث التقنيات وأعلى معايير الجودة. شريكك الموثوق في عالم النسيج.",
    quickLinks: "روابط سريعة",
    contactInfo: "معلومات التواصل",
    allRightsReserved: "جميع الحقوق محفوظة",
  },
  en: {
    // Navigation
    home: "Home",
    about: "About Us",
    products: "Our Products",
    contact: "Contact Us",
    switchToEnglish: "العربية",

    // Homepage
    heroTitle: "Quality Woven into Every Thread",
    heroSubtitle:
      "We manufacture the finest fabrics and textiles using the latest technologies and highest quality standards",
    exploreProducts: "Explore Our Products",
    contactUs: "Contact Us",

    // About snippet
    aboutTitle: "A Heritage of Creativity and Quality",
    aboutDescription1:
      "Since our establishment, we have been committed to providing the finest fabrics and textiles that combine traditional craftsmanship with modern technologies. We pride ourselves on being a trusted partner for many leading brands.",
    aboutDescription2:
      "Our specialized team works passionately to ensure that every product carries the signature of quality and excellence we are known for.",
    learnMore: "Learn More About Us",

    // Featured products
    featuredTitle: "Our Featured Products",
    featuredSubtitle: "Discover our wide range of high-quality fabrics and textiles",
    viewDetails: "View Details",
    viewAllProducts: "View All Products",

    // CTA
    ctaTitle: "Ready to Start Your Project?",
    ctaSubtitle: "Contact us today for a free consultation and customized quote for your needs",
    getQuote: "Get a Quote",
    callNow: "Call Us Now",

    // Footer
    companyName: "Al-Nahda for Textiles",
    footerDescription:
      "We manufacture the finest fabrics and textiles using the latest technologies and highest quality standards. Your trusted partner in the world of textiles.",
    quickLinks: "Quick Links",
    contactInfo: "Contact Information",
    allRightsReserved: "All Rights Reserved",
  },
}

export function getTranslation(locale: Locale, key: string): string {
  const keys = key.split(".")
  let value: any = translations[locale]

  for (const k of keys) {
    value = value?.[k]
  }

  return value || key
}
